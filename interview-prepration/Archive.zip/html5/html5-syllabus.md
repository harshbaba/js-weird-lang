==============HTML5==================
1.Key New Feature of HTML5
2.Web Workers
2.SSE
3.HTML5 Web Storage
a.Local Storage
b.Session Storage
c.Capacity of web storage
4.Cookies
5.Difference b/w Cookies & Local Storage
6.HTML5 API's
7.What is SVG
8.What is Canvas
9.Diff b/w SVG & Canvas
10.What is Quirk Mode
11.Explain <picture> tag
12.HTML5 New Form Elements
13.HTML5 Semantic Elements and Why Semantic Elements?
14.HTML5 Drag & Drop
15.Server Sent Events(SSE)
16.HTML5 - IndexedDB
17.HTML5 - WebSockets
18.Accessibility
19.Optimization
20.Async & Defer in <script>
21.<noscript> tag
22.<picture> tag
23.<datalist> tag
24.<template> Tag

